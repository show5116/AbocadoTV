package kr.or.ddit.service;

import kr.or.ddit.vo.BoardLikeVO;

public class BoardLikeServiceImp implements IBoardLikeService{

	@Override
	public boolean InsertBoardLike(BoardLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteBoardLike(BoardLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckBoardLike(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountBoardLike(String idx) {
		// TODO Auto-generated method stub
		return 0;
	}

}
