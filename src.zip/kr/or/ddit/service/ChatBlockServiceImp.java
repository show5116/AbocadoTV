package kr.or.ddit.service;

import kr.or.ddit.vo.ChatBlockVO;

public class ChatBlockServiceImp implements IChatBlockService{

	@Override
	public boolean InsertChatBlock(ChatBlockVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckChatBlock(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

}
