package kr.or.ddit.service;

import kr.or.ddit.vo.FollowerVO;

public class FollowerServiceImp implements IFollowerService{

	@Override
	public boolean InsertFollower(FollowerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteFollower(FollowerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountFollower(String mail) {
		// TODO Auto-generated method stub
		return 0;
	}

}
