package kr.or.ddit.service;

import kr.or.ddit.vo.BlogLikeVO;

public class BlogLikeServiceImp implements IBlogLikeService{

	@Override
	public boolean InsertBoardLike(BlogLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteBoardLike(BlogLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckBoardLike(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountBoardLike(String idx) {
		// TODO Auto-generated method stub
		return 0;
	}

}
