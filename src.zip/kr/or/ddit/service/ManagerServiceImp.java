package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.ManagerVO;

public class ManagerServiceImp implements IManagerService{

	@Override
	public boolean InsertManager(ManagerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteManager(ManagerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ManagerVO> SelectListManager(String mail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean CheckManager(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

}
