package kr.or.ddit.service;

import kr.or.ddit.vo.StreamingLikeVO;

public class StreamingLikeServiceImp implements IStreamingLikeDAO{

	@Override
	public boolean InsertStreamingLike(StreamingLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteStreamingLike(StreamingLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckStreamingLike(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountStreamingLike(String idx) {
		// TODO Auto-generated method stub
		return 0;
	}

}
