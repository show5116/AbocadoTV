package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.BlogCommentVO;

public class BlogCommentServiceImp implements IBlogCommentService{

	@Override
	public boolean InsertComment(BlogCommentVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateComment(BlogCommentVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<BlogCommentVO> SelectListComment(String boardIdx) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
