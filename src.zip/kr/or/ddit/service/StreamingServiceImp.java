package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.StreamingVO;

public class StreamingServiceImp implements IStreamingService{

	@Override
	public boolean InsertStreaming(StreamingVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateStreaming(StreamingVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteStreaming(StreamingVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<StreamingVO> SelectListStreaming() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<StreamingVO> SelectListStreaming(String condition) {
		// TODO Auto-generated method stub
		return null;
	}

}
