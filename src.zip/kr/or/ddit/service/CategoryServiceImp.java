package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.CategoryVO;

public class CategoryServiceImp implements ICategoryService{

	@Override
	public boolean InsertCategory(CategoryVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteCategory(CategoryVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateCategory(CategoryVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<CategoryVO> SelectCategory(String mail) {
		// TODO Auto-generated method stub
		return null;
	}

}
