package kr.or.ddit.dao;

import kr.or.ddit.vo.VisitorVO;

public class VisitorDAOImp implements IVisitorDAO{

	@Override
	public boolean UpdateVisitor() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckVisitor(String date) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean InsertVisitor(VisitorVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountVisitor(String target, String date) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int CountTotalVisitor(String target) {
		// TODO Auto-generated method stub
		return 0;
	}

}
