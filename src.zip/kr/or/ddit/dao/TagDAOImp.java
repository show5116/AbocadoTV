package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.TagVO;

public class TagDAOImp implements ITagDAO{

	@Override
	public boolean InsertTag(TagVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteTag(TagVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<TagVO> SelectListTag(String mail) {
		// TODO Auto-generated method stub
		return null;
	}

}
