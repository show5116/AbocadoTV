package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.ManagerVO;

public class ManagerDAOImp implements IManagerDAO{

	@Override
	public boolean InsertManager(ManagerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteManager(ManagerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ManagerVO> SelectListManager(String mail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean CheckManager(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

}
