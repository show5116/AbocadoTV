package kr.or.ddit.dao;

import kr.or.ddit.vo.FollowerVO;

public class FollowerDAOImp implements IFollowerDAO{

	@Override
	public boolean InsertFollower(FollowerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteFollower(FollowerVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountFollower(String mail) {
		// TODO Auto-generated method stub
		return 0;
	}

}
