package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.NoticeVO;

public class NoticeDAOImp implements INoticeDAO{

	@Override
	public boolean InsertNotice(NoticeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateNotice(NoticeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteNotice(NoticeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<NoticeVO> SelectListNotice() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NoticeVO> SelectListNotice(String category, String condition, String value) {
		// TODO Auto-generated method stub
		return null;
	}

}
