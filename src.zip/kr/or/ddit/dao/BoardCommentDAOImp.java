package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.BoardCommentVO;

public class BoardCommentDAOImp implements IBoardCommentDAO{

	@Override
	public boolean InsertComment(BoardCommentVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean UpdateComment(BoardCommentVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<BoardCommentVO> SelectListComment(String boardIdx) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
