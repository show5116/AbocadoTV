package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.SeedVO;

public class SeedDAOImp implements ISeedDAO{

	@Override
	public boolean InsertSeed(SeedVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<SeedVO> SelectSeed(String mail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int SumSales() {
		// TODO Auto-generated method stub
		return 0;
	}

}
