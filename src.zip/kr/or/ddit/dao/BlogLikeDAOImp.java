package kr.or.ddit.dao;

import kr.or.ddit.vo.BlogLikeVO;

public class BlogLikeDAOImp implements IBlogLikeDAO{

	@Override
	public boolean InsertBoardLike(BlogLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean DeleteBoardLike(BlogLikeVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckBoardLike(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int CountBoardLike(String idx) {
		// TODO Auto-generated method stub
		return 0;
	}

}
