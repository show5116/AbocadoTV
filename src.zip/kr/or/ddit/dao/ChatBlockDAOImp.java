package kr.or.ddit.dao;

import kr.or.ddit.vo.ChatBlockVO;

public class ChatBlockDAOImp implements IChatBlockDAO{

	@Override
	public boolean InsertChatBlock(ChatBlockVO vo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckChatBlock(String mail) {
		// TODO Auto-generated method stub
		return false;
	}

}
