package kr.or.ddit.vo;

public class StreamingVO {
	private String streaming_index;
	private String member_mail;
	private String streaming_category;
	private String streaming_state;
	private String streaming_starttime;
	private String streaming_endtime;
	private String streaming_count;
	private String streaming_img;
	
	public StreamingVO() {}
	public String getStreaming_index() {
		return streaming_index;
	}
	public void setStreaming_index(String streaming_index) {
		this.streaming_index = streaming_index;
	}
	public String getMember_mail() {
		return member_mail;
	}
	public void setMember_mail(String member_mail) {
		this.member_mail = member_mail;
	}
	public String getStreaming_category() {
		return streaming_category;
	}
	public void setStreaming_category(String streaming_category) {
		this.streaming_category = streaming_category;
	}
	public String getStreaming_state() {
		return streaming_state;
	}
	public void setStreaming_state(String streaming_state) {
		this.streaming_state = streaming_state;
	}
	public String getStreaming_starttime() {
		return streaming_starttime;
	}
	public void setStreaming_starttime(String streaming_starttime) {
		this.streaming_starttime = streaming_starttime;
	}
	public String getStreaming_endtime() {
		return streaming_endtime;
	}
	public void setStreaming_endtime(String streaming_endtime) {
		this.streaming_endtime = streaming_endtime;
	}
	public String getStreaming_count() {
		return streaming_count;
	}
	public void setStreaming_count(String streaming_count) {
		this.streaming_count = streaming_count;
	}
	public String getStreaming_img() {
		return streaming_img;
	}
	public void setStreaming_img(String streaming_img) {
		this.streaming_img = streaming_img;
	}
}
