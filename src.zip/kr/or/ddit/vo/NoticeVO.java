package kr.or.ddit.vo;

public class NoticeVO {
	private String notice_index;
	private String member_mail;
	private String notice_date;
	private String notice_count;
	private String notice_cotent;
	private String notice_title;
	private String notice_category;
	
	public NoticeVO() {}
	public String getNotice_index() {
		return notice_index;
	}
	public void setNotice_index(String notice_index) {
		this.notice_index = notice_index;
	}
	public String getMember_mail() {
		return member_mail;
	}
	public void setMember_mail(String member_mail) {
		this.member_mail = member_mail;
	}
	public String getNotice_date() {
		return notice_date;
	}
	public void setNotice_date(String notice_date) {
		this.notice_date = notice_date;
	}
	public String getNotice_count() {
		return notice_count;
	}
	public void setNotice_count(String notice_count) {
		this.notice_count = notice_count;
	}
	public String getNotice_cotent() {
		return notice_cotent;
	}
	public void setNotice_cotent(String notice_cotent) {
		this.notice_cotent = notice_cotent;
	}
	public String getNotice_title() {
		return notice_title;
	}
	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}
	public String getNotice_category() {
		return notice_category;
	}
	public void setNotice_category(String notice_category) {
		this.notice_category = notice_category;
	}
	
}
